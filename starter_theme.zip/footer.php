		</div> <!-- END WRAPPER -->	
		<footer>
			<p>&copy; <?= date('Y'); ?> <a href="<?php bloginfo('url'); ?>/" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></p>
		</footer>
		<?php wp_footer(); ?>

	</body>
</html>